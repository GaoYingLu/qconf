Qconf monitor responsible for checking service availible.
