package net.qihoo.qconf;
public class QconfException extends Exception
{
    public QconfException()
    {}
    public QconfException(String msg)
    {
        super(msg);
    }
}
